﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandle1
{
    class Program
    {
        static void Main(string[] args)
        {

            string filename = @"C:\Users\Prashant\Desktop\Employee.txt";
            string filename1 = @"C:\Users\Prashant\Desktop\Department.txt";
            string filename2 = @"C:\Users\Prashant\Desktop\Project.txt";
           // List<Employee> emprec = new List<Employee>();
           // List<Department> deprec = new List<Department>();
            //List<Project> prorec = new List<Project>();
            int ch;
            string line;
            do
            {
                Console.WriteLine("1 Insert in to the Employee File");
                Console.WriteLine("2 Insert in to the Department File");
                Console.WriteLine("3 Insert in to the Project File");
                Console.WriteLine("4 Display Employee Record");
                Console.WriteLine("5 Display Department Record");
                Console.WriteLine("6 Display project Record");
                Console.WriteLine("7 Get project Info by Employee ID");
                Console.WriteLine("8 Get Employee Info by Depart ID");
                Console.WriteLine("9 Get Employee Info by Depart Name");
                Console.WriteLine("10 Exit");
                Console.Write("Enter the choice = ");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:Employee emp = new Employee();
                        try
                        {
                            if (emp.checkDuplicate(filename) == true)
                            {
                                using (StreamWriter writer = new StreamWriter(filename, true))
                                {
                                    writer.Write(emp);
                                }
                            }
                            else
                            {
                                Console.WriteLine("===========Employee id is already presnt in the file===========");
                            }
                        }
                        catch (Exception e1)
                        {
                            Console.WriteLine(e1.Message);
                        }
                        break;
                    case 2:Department dep = new Department();
                        try
                        {
                            if (dep.checkDuplicate1(filename1) == true)
                            {
                                using (StreamWriter writer = new StreamWriter(filename1, true))
                                {

                                    writer.Write(dep);
                                 }
                           }
                                else
                                {
                                    Console.WriteLine("========Department id is already presnt in the file==========");
                                }
                            }
                        
                        catch (Exception e1)
                        {
                            Console.WriteLine(e1.Message);
                        }
                        break;
                    case 3:Project pro = new Project();
                        try
                        {
                            if (pro.checkDuplicate2(filename2) == true)
                            {
                                using (StreamWriter writer = new StreamWriter(filename2, true))
                                {
                                    writer.Write(pro);
                                }
                            }
                            else
                            {
                                Console.WriteLine("=======project id is already used=======");
                            }
                        }
                        catch (Exception e1)
                        {
                            Console.WriteLine(e1.Message);
                        }
                        break;
                    case 4:StreamReader reader1 = new StreamReader(filename);
                        while ((line = reader1.ReadLine()) != null)
                        {
                            Console.WriteLine(line + "\n");
                        }
                        break;
                    case 5:
                        StreamReader reader2 = new StreamReader(filename1);
                        while ((line = reader2.ReadLine()) != null)
                        {
                            Console.WriteLine(line + "\n");
                        }
                        break;
                    case 6:
                        StreamReader reader3 = new StreamReader(filename2);
                        while ((line = reader3.ReadLine()) != null)
                        {
                            Console.WriteLine(line + "\n");
                        }
                        break;
                    case 7:
                        Console.WriteLine("Enter the Empid");
                        string ID = Console.ReadLine();
                        Connectfile.projectbyempID(ID, filename, filename2);
                        break;
                    case 8:
                        Console.WriteLine("Enter the Department ID");
                        string ID1 = Console.ReadLine();
                        Connectfile.EmpInfobyDeptID(ID1, filename, filename1);
                        break;
                    case 9:
                        Console.WriteLine("Enter the Department Name");
                        string name = Console.ReadLine();
                        Connectfile.searchbyDeptname(name, filename, filename1);
                        break;
                    case 10: Console.WriteLine("Successfully loged out"); break;
                    default: Console.WriteLine("Invalid choice"); break;
                }

            } while (ch!=10);
        }
    }
}
