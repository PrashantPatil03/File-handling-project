﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandle1
{
    class Project
    {
        public int Pid, MagId;
        public string Pname;

        public Project()
        {
            Console.WriteLine("Enter the Project ID");
            Pid = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Project Name");
            Pname = Console.ReadLine();

            Console.WriteLine("Enter the Manager Id");
            MagId = int.Parse(Console.ReadLine());
        }
        public override string ToString()
        {
            return (Pid.ToString().PadLeft(20) + " | " + Pname.PadLeft(20) + " | " + MagId.ToString().PadLeft(20));
        }
        internal bool checkDuplicate2(string ProPath)
        {
            string lines;
            StreamReader reader = new StreamReader(ProPath);
            while ((lines = reader.ReadLine()) != null)
            {
                if (lines.Substring(17, 3) == this.Pid.ToString())
                {
                    //Console.WriteLine(EmpID);
                    Console.WriteLine("enter valid department id because it's already used!!!");
                    reader.Close();
                    return false;

                }
            }
            reader.Close();
            return true;
        }


    }
}
